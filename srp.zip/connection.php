<?php

$databaseHost = 'localhost:3306';
$databaseName = 'srp'; 
$databaseUsername = 'root'; 
$databasePassword = '';  
$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);
 
?>