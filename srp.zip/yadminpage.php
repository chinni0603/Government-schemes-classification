<!DOCTYPE html>
<html>
<body>
<a href="http://localhost/insertion/yinsert.php"></a>
</body>
</html>