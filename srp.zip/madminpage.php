<!DOCTYPE html>
<html>
<body>
<a href="http://localhost/insertion/minsert.php"></a>
</body>
</html>