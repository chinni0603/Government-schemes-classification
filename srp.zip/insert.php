<!DOCTYPE html>
<html>
  <body>
<h1 style="color:blue">Update the schemes of female</h1>
	<form method="post" action="process.php">
		Logo:<br>
		<input type="text" name="Logo">
		<br>
		Scheme:<br>
		<input type="text" name="Scheme">
		<br>
		Details:<br>
		<input type="text" name="Details">
		<br>
		url:<br>
		<input type="text" name="url">
		<br><br>
		<input type="submit" name="save" value="submit">
	</form>
  </body>
</html>