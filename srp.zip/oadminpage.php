<!DOCTYPE html>
<html>
<body>
<a href="http://localhost/insertion/oinsert.php"></a>
</body>
</html>