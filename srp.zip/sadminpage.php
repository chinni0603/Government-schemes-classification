<!DOCTYPE html>
<html>
<body>
<a href="http://localhost/insertion/sinsert.php"></a>
</body>
</html>