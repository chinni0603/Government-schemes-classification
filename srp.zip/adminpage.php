<!DOCTYPE html>
<html>
<body>
<a href="http://localhost/insertion/insert.php"></a>
</body>
</html>