<!DOCTYPE html>
<html>
<body>
<a href="http://localhost/insertion/cinsert.php"></a>
</body>
</html>