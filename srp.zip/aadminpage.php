<!DOCTYPE html>
<html>
<body>
<a href="http://localhost/insertion/ainsert.php"></a>
</body>
</html>